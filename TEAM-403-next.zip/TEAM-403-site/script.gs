/** TEAM 403 backend skeleton. Deploy as a Web App. */
const SHEET_NAME = 'Complaints';

function setup(){
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(SHEET_NAME);
  if(!sh) sh = ss.insertSheet(SHEET_NAME);
  if(sh.getLastRow() === 0) sh.appendRow(['id','time','name','message','reply']);
}

function doPost(e){
  setup();
  const data = JSON.parse(e.postData.contents || '{}');
  const sh = SpreadsheetApp.getActive().getSheetByName(SHEET_NAME);
  const id = Utilities.getUuid();
  sh.appendRow([id,new Date(),String(data.name||'بدون اسم'),String(data.message||''),'']);
  return json({ok:true,id});
}

function doGet(){
  return json({ok:true,service:'TEAM 403'});
}

function json(obj){
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
