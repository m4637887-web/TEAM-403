TEAM 403 — الخطوة التالية للشكاوى

الموقع نفسه ثابت على GitHub Pages، لذلك لا يستطيع حفظ الشكاوى بين أجهزة الزوار بدون Backend.
الملف script.gs الموجود هنا هو نقطة البداية لربط Google Apps Script + Google Sheets.

مهم: لا تضع كلمات مرور الأدمن داخل index.html. كلمة مرور الأدمن يجب أن تبقى في Script Properties في Apps Script.
